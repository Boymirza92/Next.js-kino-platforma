"use client"
import styled from "styled-components";
// import "./styled.css";


const Home = () => {
  return (
    <div>
     
    </div>
  );
};

export default Home;
