import Image from "next/image";
// import CartoonsPage from "./loyiha/cartoons/page"
// import FantasyPage from "./loyiha/fantasy/page"
// import HomePage from "./loyiha/home/page"
// import NavbarPage from "./loyiha/navbarpage"
// import PopularPage from "./loyiha/popular/page"
// import WarPage from "./loyiha/war/page"
export default function Home() {
  return (
    <div>
      {/* <h1> Mendurman o'sha</h1>
      <HomePage/>
     <CartoonsPage/>
     <FantasyPage/>
     <NavbarPage/>
     <PopularPage/>
     <WarPage/> */}

    </div>
  );
}
