// import Navbar from '../components/Navbar';
import Navbar from './components/Navbar';
import MovieCard from './components/movieCard';
 export function navbar () {
    return (
        <div>
        <Navbar/>
        <h1>Navbar page</h1>
        <MovieCard/>
        </div>
    )
 }