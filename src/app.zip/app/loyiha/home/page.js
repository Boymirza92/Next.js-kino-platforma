// import Link from "next/link";

// export default function Home() {
//   return (
//     // <div>
//     //   <h1>Welcome to the Movie Platform</h1>
//     //   <Link href="/popular">Go to Popular Movies</Link>
//     //   <Link href="/cartoons">Go to Cartoons Movies</Link>
//     //   <Link href="/fantasy">Go to Fantasy Movies</Link>
//     //   <Link href="/war">Go to Popular Movies</Link>
//     //   <Link href="/navbar">Go to navbar</Link>
//     // </div>
//   );
// }
  