// import styled from "styled-components";

// const Card = styled("div")`
//   border: 1px solid #ccc;
//   border-radius: 8px;
//   padding: 16px;
//   width: 200px;
//   text-align: center;
//   background-color: #f9f9f9;
//   box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
// `;

// const MovieCard = ({ movie }) => {
//   return (
//     <Card>
//       <h3>{movie.title}</h3>
//       <p>Year: {movie.year}</p>
//       <p>Rating: {movie.rating}</p>
//     </Card>
//   );
// };

// export default MovieCard;

import React from "react";
import styled from "styled-components";

const Card = styled("div")`
  border: 1px solid #ddd;
  padding: 1rem;
  border-radius: 8px;
  width: 200px;
  text-align: center;
`;

const MovieCard = ({ movie }) => {
  return (
    <Card>
      <h3>{movie.title}</h3>
      <p>{movie.year}</p>
    </Card>
  );
};

export default MovieCard;
